OrgTools
--------------

Requirements
------------

Java 1.5.0 or later
Expat

Operating systems
-----------------

Microsoft Windows
Linux

Installing instructions
-----------------------

Linux
-----

To use ORGTools under Linux you need to install SBW ( http://sbw.kgi.edu/research/sbwIntro.htm) first. Make sure that the paths to the libraries of SBW (.../SBW/lib/)
and to libSBML.so are available via LD_LIBRARY_PATH. SBW normally sets this variable itself. Under SuSE you can do this by adding

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/Path/To/SBW/lib/

to your .bashrc. Additionally you might need to set the SBW_HOME variabel by

export SBW_HOME=/Path/To/SBW/

When you want to use OrgTools with SBW you need to make sure that the Broker is running by typing

sh start.sh

in the SBW home directory.

To install OrgTools you just need to untar the archive file. Afterwards, by issuing

sh build

OrgTools is being installed. Please note that everytime you change your SBW or Java installation you
need to run the registerModules script in the OrgTools home directory to reconnect them to SBW.

To check if everything went right you can start the SBWInspector by typing

./SBWInspector

in the OrgTools home directory. In the tab "RegisteredModules" you should find the modules of SBWOrgAnalysis,
which are orgViewApp and orgAnalysis.

To compute the organizations of a reaction network you can either run OrgAnalysis by typing

./OrgAnalysis

or through the call of "examine organizational structure of reaction networks" in any SBW compliant application, e.g.
CellDesigner. You can compute organizations by the option "Analysis/Organization Analysis" or "Analysis/Search organizations with old algorithm". 
After computation has finished the lattice should appear in .ltc format in the tab NetworkAnalysis.
It can be visualized by choosing "SBW/LatticeTools/examine structure of lattice (orgView)" in the menu.
If you do not find the option "SBW" in the menu you need to start the SBW broker like described above. Alternatively the
menu option should appear if you restart OrgAnalysis.


Windows
-------

To use SBWOrgAnalysis under Windows you need to install SBW ( http://sbw.kgi.edu/research/sbwIntro.htm ).

Before installation make sure that the SBW-Broker is running (e.g. by starting it from the start menu).
Afterwards you just need to run the installer.

To check if everything went right you can start the SBWInspector which is shipped with the SBW distribution
(also available from the start menu). In the tab "RegisteredModules" you should find the modules of SBWOrgAnalysis,
which are orgViewApp, reaTranslator, ecocycTools and orgAnalysis.

To compute the organizations of a reaction network you can either run OrgAnalysis by double-clicking the "OrgAnalysis.bat"
or through the call of "examine organizational structure of reaction networks" in any SBW compliant application, e.g.
JDesigner. 
You can compute organizations by the option "Analysis/Organization Analysis" or "Analysis/Search organizations
with old algorithm". After computation has finished the lattice should appear in .ltc format in the tab NetworkAnalysis.
It can be visualized by choosing "SBW/LatticeTools/examine structure of lattice (orgView)" in the menu.
If you do not find the option "SBW" in the menu you need to start the SBW broker like described above. Alternatively the
menu option should appear if you restart OrgAnalysis.


Known Issues
------------

Linux
-----

If you encounter an error during the compilation of lpSolve, make sure that your $JDK_HOME variable is properly set.

When Compiz window manager is used, the GUI is only displayed as a grey window without any content. Installing JRE 1.6 or
later should fix the problem.

