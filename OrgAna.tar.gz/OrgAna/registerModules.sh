#!/bin/bash

#setting library paths
THISDIR=`pwd`
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${THISDIR}/lib

#registering modules
java -jar ./jar/OrgAnalysis.jar -sbwregister
java -jar ./jar/orgView.jar -sbwregister


